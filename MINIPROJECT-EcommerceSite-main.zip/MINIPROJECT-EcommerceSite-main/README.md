# MINIPROJECT

## This is Second Year MiniProject Topic- Sales prediction using E-commerce.

## Work Flow:- 

1. First the user has to  create and account and register him/her self
2. Than only the user can buy the items and put the items in the cart other wise the cart is not visible to the user
3. There is  payment gateway (but a fake one)
4. Than only the admin can view the dashboard which contains all the analytics.

## Prediction
The prediction is based on the data which was recieved from the website where we team members did fake purchases and generated and EXCEL sheet and  was give to 
our prediction modal which gave us the graphs and in which the orange line is the predicted sales based on the quantity... 
  
## Main Motive (scope)
The prediction made will help small businesses to grow and and also help them know which product to keep  in inventory  and help them establish.
## Preview

### First view of the website
![image](https://github.com/Merwin-Rebello/MINIPROJECT/assets/110761387/fb7f7848-3fa3-49d1-8032-70e3d7c1d107)

### Category pages
![image](https://github.com/Merwin-Rebello/MINIPROJECT/assets/110761387/85b2c432-c2fb-4830-9499-678f9c9dfe74)

### login page
![image](https://github.com/Merwin-Rebello/MINIPROJECT/assets/110761387/d4eff025-2c9b-4f89-923e-896137cef226)

### Registration page
![image](https://github.com/Merwin-Rebello/MINIPROJECT/assets/110761387/d0f81bce-bedb-4067-8ee3-a4119ebd5d16)

### Cart Page
![image](https://github.com/Merwin-Rebello/MINIPROJECT/assets/110761387/79c33324-53ef-4a2c-8e21-09c2534a2811)

### Payment page
![image](https://github.com/Merwin-Rebello/MINIPROJECT/assets/110761387/78f52d9e-dc6d-4dda-821d-d16b7ae72969)

### Dashboard 
![image](https://github.com/Merwin-Rebello/MINIPROJECT/assets/110761387/bb9f087a-d1a8-4e50-83ff-170ade7cf07a)

## Languages 
1. DJANGO (OVERALL MAIN FAMEWORK)
2. JAVASCRIPT
3. HTML,CSS
### Team Members

1. Merwin Rebello(Developer)
2. Noel Sangle (Machine Learning)
3. Shubham Keluskar

#### Acknowledgement 
We would like to thank our project guide  and special mention also to  our classmate Sahil Singh ( https://github.com/Sahil5111 )  who has also helped and contributed in this project.
